// automatically generated file.
#define Z3_MAJOR_VERSION   4
#define Z3_MINOR_VERSION   8
#define Z3_BUILD_NUMBER    18
#define Z3_REVISION_NUMBER 0

#define Z3_FULL_VERSION    "4.8.18.0 ea2a84332513a7823e8e5c96f039fd048cb43dc5 z3-4.8.4-6376-gea2a84332"
#define Z3GITHASH ea2a84332513a7823e8e5c96f039fd048cb43dc5
